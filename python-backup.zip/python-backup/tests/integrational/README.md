## VCR

### Matchers
Default VCR.py matchers are: 'method', 'scheme', 'host', 'port', 'path', 'query'
PubNub custom VCR.py matchers are defined inside vcr_helper.py